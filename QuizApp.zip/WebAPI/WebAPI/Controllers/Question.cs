﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebAPI.Controllers
{
    public struct Question
    {
        public string text { get; set; }
        public List<string> answers { get; set; }
        public List<int> correct { get; set; }
        public string type { get; set; }
        public string tutorial { get; set; }
        public List<int> useroption { get; set; }

    }
}
