﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebAPI.Controllers
{
    public struct Question
    {
        public string text { get; set; }//question
        public List<string> answers { get; set; }//array of answers
        public List<int> correct { get; set; }//array of correct options
        public string type { get; set; }//question type
        public string tutorial { get; set; }//tutorial for the question
        public List<int> useroption { get; set; }//to save the selected options of user

    }
}
