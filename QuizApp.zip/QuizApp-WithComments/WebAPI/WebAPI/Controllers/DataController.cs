﻿using LinqToExcel;
using System.Data;
using System.Data.OleDb;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace WebAPI.Controllers
{
    public class DataController : ApiController
    {
        // GET: Data

        //string filename = "C:\\Users\\mslc.MSLC\\Desktop\\WEBAPI\\testdata.xlsx";
        ExcelQueryFactory bank = new ExcelQueryFactory("C:\\Users\\mslc.MSLC\\Desktop\\WEBAPI\\testdata.xlsx");//excel file path

        [HttpGet]
        [Route("api/Data/GetList")]
        public IEnumerable<string> GetList()//returns the worksheet names of the excel file
        {
            return bank.GetWorksheetNames().ToList();
        }

        [HttpGet]
        [Route("api/Data/GetQuestions/{topic}")]
        public IEnumerable<Question> GetQuestions(string topic)//returns the questions array of the selected topic ie: worksheet
        {
            var items = bank.Worksheet(topic);
            List<Question> qlist = new List<Question>();

            foreach( var item in items)
            {
                Question q = new Question();
                q.correct = new List<int>();
                q.answers = new List<string>();
                q.useroption = new List<int>();
                q.text = item["Question"].Value.ToString();
                
                if(item["Option1"].Value.ToString()!="")
                    q.answers.Add(item["Option1"].Value.ToString());
                if (item["Option2"].Value.ToString() != "")
                    q.answers.Add(item["Option2"].Value.ToString());
                if (item["Option3"].Value.ToString() != "")
                    q.answers.Add(item["Option3"].Value.ToString());
                if (item["Option4"].Value.ToString() != "")
                    q.answers.Add(item["Option4"].Value.ToString());
                                
                q.correct = item["CorrectAnswer"].Value.ToString().Split(',').Select(n => Convert.ToInt32(n)).ToList<int>();//from the correct answer string this will convert to array
                q.tutorial = item["Tutorial"].Value.ToString();
                q.type = item["Type"].Value.ToString();
                qlist.Add(q);//adds to the question list
            }


            return qlist;
        }

        
            
    }
}